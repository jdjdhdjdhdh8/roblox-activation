'use strict';

/**
 * أداة محلية اختيارية لإنشاء/تحديث حسابات إدارة مباشرة في قاعدة البيانات.
 * تستخدم فقط إذا كنت تشغّل المشروع على جهازك أو VPS وتقدر تصل لملف قاعدة البيانات مباشرة.
 *
 * إذا كان المشروع مستضافًا على Discloud أو مكان لا تملك فيه وصولًا مباشرًا للملفات،
 * استخدم بدلًا من هذا السكربت نقطة /api/setup/admins الموضحة في README (عبر curl).
 *
 * الاستخدام:
 *   node scripts/create-admins.js اسم1:كلمة_مرور1 اسم2:كلمة_مرور2 اسم3:كلمة_مرور3
 *
 * ملاحظة: كلمة المرور تظهر على الشاشة وفي سجل الأوامر (history) لأنها تُمرَّر كوسيط.
 * شغّل هذا فقط على جهازك الشخصي، ولا تستخدمه في سكربتات أو سجلات مشتركة.
 */

require('../src/config'); // يتحقق من .env أولًا
const db = require('../src/db');
const auth = require('../src/auth');

async function main() {
  const pairs = process.argv.slice(2);

  if (pairs.length === 0) {
    console.log('الاستخدام: node scripts/create-admins.js اسم1:كلمة_مرور1 اسم2:كلمة_مرور2 ...');
    process.exit(1);
  }

  for (const pair of pairs) {
    const sep = pair.indexOf(':');
    if (sep === -1) {
      console.error(`❌ تجاهلت "${pair}": الصيغة يجب أن تكون username:password`);
      continue;
    }

    const username = pair.slice(0, sep);
    const password = pair.slice(sep + 1);

    if (!auth.validUsername(username)) {
      console.error(`❌ تجاهلت "${username}": اسم مستخدم غير صالح (حروف إنجليزية/أرقام/_ فقط، 3-32 حرفًا)`);
      continue;
    }
    if (!auth.validPassword(password)) {
      console.error(`❌ تجاهلت "${username}": كلمة المرور قصيرة جدًا (${auth.MIN_PASSWORD_LENGTH} أحرف على الأقل)`);
      continue;
    }

    const passwordHash = await auth.hashPassword(password);
    db.upsertAdmin({ username, passwordHash });
    console.log(`✅ تم إنشاء/تحديث الحساب: ${username}`);
  }

  console.log(`\nإجمالي حسابات الإدارة الآن: ${db.countAdmins()}`);
  db.close();
}

main();
