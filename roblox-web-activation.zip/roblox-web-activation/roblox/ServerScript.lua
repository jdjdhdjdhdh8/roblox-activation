--[[
    نظام التفعيل - Server Script (Luau)

    مكانه: ServerScriptService  (يجب أن يكون Script عادي، وليس LocalScript)
    لا تضعه داخل StarterPlayer أو StarterGui أو ReplicatedStorage.

    قبل التشغيل:
    1) Game Settings > Security > فعّل "Allow HTTP Requests"
    2) غيّر API_BASE_URL إلى رابط الاستضافة الخاص بك (https)
    3) ضع المفتاح السري في Secrets Store (الأفضل) أو مؤقتًا في FALLBACK_KEY للاختبار
]]

local Players = game:GetService("Players")
local HttpService = game:GetService("HttpService")
local RunService = game:GetService("RunService")

local CONFIG = {
	-- رابط الـ API بدون / في النهاية
	API_BASE_URL = "https://YOUR-APP.example.com",

	-- الطريقة الآمنة: المفتاح مخزن في Roblox Secrets Store ولا يظهر في الكود
	USE_SECRETS_STORE = true,
	SECRET_NAME = "ACTIVATION_KEY",
	-- للاختبار فقط إذا لم يعمل Secrets Store في Studio. احذفه قبل النشر!
	FALLBACK_KEY = "",

	-- ماذا نفعل إذا تعذر الاتصال بالـ API؟
	-- false = (الأفضل) اطرد اللاعب. true = اسمح له بالدخول.
	FAIL_OPEN = false,

	MAX_ATTEMPTS = 3, -- عدد محاولات الاتصال قبل اعتباره خطأ
	RETRY_DELAY = 2, -- ثواني الانتظار بين المحاولات (تزيد تدريجيًا)

	-- إذا كان اللاعب متحققًا قبل أقل من هذه المدة (ثواني) وتعطل الـ API، نسمح له بالبقاء
	GRACE_SECONDS = 600,

	-- إعادة فحص اللاعبين الموجودين كل فترة (ثواني)، لطرد من أُلغي تفعيله أثناء اللعب. 0 = إيقاف
	RECHECK_INTERVAL = 300,

	-- تخطي الفحص داخل Roblox Studio (للتطوير فقط، اجعله false في النسخة الحقيقية)
	SKIP_IN_STUDIO = false,

	KICK_NOT_ACTIVATED = "أنت غير مفعّل. توجه إلى Discord لتفعيل حسابك.",
	KICK_API_ERROR = "تعذر التحقق من التفعيل حاليًا. حاول الدخول بعد قليل.",
}

-- userId -> وقت آخر تحقق ناجح
local lastVerified: { [number]: number } = {}

local function getKey()
	if CONFIG.USE_SECRETS_STORE then
		return HttpService:GetSecret(CONFIG.SECRET_NAME)
	end
	return CONFIG.FALLBACK_KEY
end

-- يرجع: "yes" (مفعّل) | "no" (غير مفعّل) | "error" (تعذر التحقق)
local function checkActivation(userId: number): string
	-- لاعبو الاختبار في Studio لهم UserId سالب أو صفر، وهم غير مفعّلين بطبيعة الحال
	if userId <= 0 then
		return "no"
	end

	local url = string.format("%s/api/roblox/check/%d", CONFIG.API_BASE_URL, userId)

	for attempt = 1, CONFIG.MAX_ATTEMPTS do
		local ok, response = pcall(function()
			return HttpService:RequestAsync({
				Url = url,
				Method = "GET",
				Headers = {
					["x-api-key"] = getKey(),
					["Accept"] = "application/json",
				},
			})
		end)

		if ok and response.Success then
			local decoded, data = pcall(function()
				return HttpService:JSONDecode(response.Body)
			end)
			if decoded and type(data) == "table" and type(data.activated) == "boolean" then
				return data.activated and "yes" or "no"
			end
		elseif ok and (response.StatusCode == 401 or response.StatusCode == 403) then
			-- المفتاح خاطئ: إعادة المحاولة لن تفيد
			warn("[Activation] المفتاح السري مرفوض من الـ API. تحقق من الإعدادات.")
			return "error"
		elseif not ok then
			warn("[Activation] فشل الاتصال:", response)
		end

		if attempt < CONFIG.MAX_ATTEMPTS then
			task.wait(CONFIG.RETRY_DELAY * attempt)
		end
	end

	return "error"
end

local function handlePlayer(player: Player, isRecheck: boolean)
	if CONFIG.SKIP_IN_STUDIO and RunService:IsStudio() then
		return
	end

	local userId = player.UserId
	local status = checkActivation(userId)

	if not player.Parent then
		return -- اللاعب خرج أثناء الفحص
	end

	if status == "yes" then
		lastVerified[userId] = os.clock()
		return
	end

	if status == "no" then
		lastVerified[userId] = nil
		player:Kick(CONFIG.KICK_NOT_ACTIVATED)
		return
	end

	-- status == "error": مشكلة في الاتصال
	local last = lastVerified[userId]
	if last and (os.clock() - last) < CONFIG.GRACE_SECONDS then
		return -- تم التحقق منه مؤخرًا، لا نطرده بسبب عطل مؤقت
	end

	if CONFIG.FAIL_OPEN then
		warn(string.format("[Activation] تعذر التحقق من %s، تم السماح له (FAIL_OPEN).", player.Name))
		return
	end

	if not isRecheck then
		player:Kick(CONFIG.KICK_API_ERROR)
	end
	-- في إعادة الفحص الدورية لا نطرد أحدًا بسبب خطأ اتصال؛ نطرد فقط عند "no" مؤكد
end

Players.PlayerAdded:Connect(function(player)
	task.spawn(handlePlayer, player, false)
end)

-- لاعبون دخلوا قبل أن يبدأ السكربت
for _, player in ipairs(Players:GetPlayers()) do
	task.spawn(handlePlayer, player, false)
end

Players.PlayerRemoving:Connect(function(player)
	lastVerified[player.UserId] = nil
end)

-- إعادة فحص دورية
if CONFIG.RECHECK_INTERVAL > 0 then
	task.spawn(function()
		while true do
			task.wait(CONFIG.RECHECK_INTERVAL)
			for _, player in ipairs(Players:GetPlayers()) do
				task.spawn(handlePlayer, player, true)
			end
		end
	end)
end
