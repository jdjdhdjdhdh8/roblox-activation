'use strict';

// يقرأ ملف .env ويتأكد أن كل شيء موجود قبل تشغيل أي شيء.
require('dotenv').config();

function fail(message) {
  console.error(`❌ ${message}`);
  process.exit(1);
}

function required(name) {
  const value = process.env[name];
  if (!value || !value.trim()) fail(`المتغير ${name} ناقص في ملف .env`);
  return value.trim();
}

function requiredSecret(name, minLen = 32) {
  const value = required(name);
  if (value.length < minLen) {
    fail(`المتغير ${name} قصير جدًا. استخدم ${minLen} حرفًا على الأقل (انظر README لطريقة توليد مفتاح قوي).`);
  }
  return value;
}

const config = {
  port: Number(process.env.PORT) || 8080, // Discloud يتطلب المنفذ 8080
  dbPath: (process.env.DB_PATH || './data/activations.db').trim(),
  sessionSecret: requiredSecret('SESSION_SECRET'),
  robloxApiKey: requiredSecret('ROBLOX_API_KEY'),
  setupApiKey: requiredSecret('SETUP_API_KEY'),
};

if (new Set([config.sessionSecret, config.robloxApiKey, config.setupApiKey]).size !== 3) {
  fail('SESSION_SECRET و ROBLOX_API_KEY و SETUP_API_KEY يجب أن تكون ثلاث قيم مختلفة عن بعضها.');
}

module.exports = config;
