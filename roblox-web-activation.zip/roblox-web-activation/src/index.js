'use strict';

const config = require('./config'); // يتحقق من .env أولًا
const db = require('./db');
const { createApp } = require('./web');

const app = createApp();
const server = app.listen(config.port, '0.0.0.0', () => {
  console.log(`🌐 الموقع يعمل على المنفذ ${config.port}`);
  if (db.countAdmins() === 0) {
    console.log('⚠️  لا يوجد أي حساب إدارة بعد. انظر README لإنشاء أول حساب عبر /api/setup/admins');
  }
});

function shutdown(signal) {
  console.log(`\n${signal} — إيقاف النظام...`);
  server.close(() => {
    db.close();
    process.exit(0);
  });
  setTimeout(() => process.exit(0), 5000).unref();
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('unhandledRejection', (err) => console.error('Unhandled rejection:', err));
