'use strict';

const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');
const config = require('./config');

fs.mkdirSync(path.dirname(path.resolve(config.dbPath)), { recursive: true });

const db = new Database(config.dbPath);
db.pragma('journal_mode = WAL');

// المعرّف الأساسي هو roblox_user_id (لا يتغير أبدًا)، وليس الاسم (يمكن تغييره)
db.exec(`
  CREATE TABLE IF NOT EXISTS activations (
    roblox_user_id          INTEGER PRIMARY KEY,
    roblox_username         TEXT    NOT NULL,
    activated_by            TEXT    NOT NULL,
    activated_at            TEXT    NOT NULL,
    updated_at              TEXT    NOT NULL
  );

  CREATE TABLE IF NOT EXISTS admins (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT    NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT    NOT NULL,
    created_at    TEXT    NOT NULL,
    updated_at    TEXT    NOT NULL
  );
`);

const stmts = {
  get: db.prepare('SELECT * FROM activations WHERE roblox_user_id = ?'),
  upsert: db.prepare(`
    INSERT INTO activations
      (roblox_user_id, roblox_username, activated_by, activated_at, updated_at)
    VALUES
      (@userId, @username, @activatedBy, @now, @now)
    ON CONFLICT(roblox_user_id) DO UPDATE SET
      roblox_username = excluded.roblox_username,
      activated_by     = excluded.activated_by,
      updated_at       = excluded.updated_at
  `),
  remove: db.prepare('DELETE FROM activations WHERE roblox_user_id = ?'),
  count: db.prepare('SELECT COUNT(*) AS total FROM activations'),
  list: db.prepare(`
    SELECT * FROM activations
    WHERE (@search = '' OR roblox_username LIKE '%' || @search || '%' OR CAST(roblox_user_id AS TEXT) = @search)
    ORDER BY activated_at DESC
    LIMIT @limit OFFSET @offset
  `),

  getAdminByUsername: db.prepare('SELECT * FROM admins WHERE username = ?'),
  getAdminById: db.prepare('SELECT * FROM admins WHERE id = ?'),
  upsertAdmin: db.prepare(`
    INSERT INTO admins (username, password_hash, created_at, updated_at)
    VALUES (@username, @passwordHash, @now, @now)
    ON CONFLICT(username) DO UPDATE SET
      password_hash = excluded.password_hash,
      updated_at    = excluded.updated_at
  `),
  countAdmins: db.prepare('SELECT COUNT(*) AS total FROM admins'),
};

function activate({ userId, username, activatedBy }) {
  const existing = stmts.get.get(userId);
  stmts.upsert.run({ userId, username, activatedBy, now: new Date().toISOString() });
  return { created: !existing, record: stmts.get.get(userId) };
}

function deactivate(userId) {
  return stmts.remove.run(userId).changes > 0;
}

function getActivation(userId) {
  return stmts.get.get(userId);
}

function countActivations() {
  return stmts.count.get().total;
}

function listActivations({ search = '', limit = 50, offset = 0 } = {}) {
  return stmts.list.all({ search, limit, offset });
}

function getAdminByUsername(username) {
  return stmts.getAdminByUsername.get(username);
}

function getAdminById(id) {
  return stmts.getAdminById.get(id);
}

function upsertAdmin({ username, passwordHash }) {
  stmts.upsertAdmin.run({ username, passwordHash, now: new Date().toISOString() });
  return stmts.getAdminByUsername.get(username);
}

function countAdmins() {
  return stmts.countAdmins.get().total;
}

function close() {
  db.close();
}

module.exports = {
  activate,
  deactivate,
  getActivation,
  countActivations,
  listActivations,
  getAdminByUsername,
  getAdminById,
  upsertAdmin,
  countAdmins,
  close,
};
