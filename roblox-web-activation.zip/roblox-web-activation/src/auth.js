'use strict';

const bcrypt = require('bcryptjs');

const USERNAME_REGEX = /^[A-Za-z0-9_]{3,32}$/;
const MIN_PASSWORD_LENGTH = 8;

function validUsername(username) {
  return typeof username === 'string' && USERNAME_REGEX.test(username);
}

function validPassword(password) {
  return typeof password === 'string' && password.length >= MIN_PASSWORD_LENGTH;
}

async function hashPassword(password) {
  return bcrypt.hash(password, 12);
}

async function verifyPassword(password, hash) {
  return bcrypt.compare(password, hash);
}

module.exports = {
  validUsername,
  validPassword,
  hashPassword,
  verifyPassword,
  MIN_PASSWORD_LENGTH,
};
