'use strict';

const crypto = require('crypto');
const path = require('path');
const express = require('express');
const cookieSession = require('cookie-session');
const rateLimit = require('express-rate-limit');
const config = require('./config');
const db = require('./db');
const roblox = require('./roblox');
const auth = require('./auth');

/** مقارنة آمنة للمفاتيح (تمنع هجمات قياس الوقت) */
function safeEqual(a, b) {
  const ha = crypto.createHash('sha256').update(String(a)).digest();
  const hb = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(ha, hb);
}

function requireKey(expectedKey) {
  return (req, res, next) => {
    const provided = req.get('x-api-key') || '';
    if (!safeEqual(provided, expectedKey)) return res.status(401).json({ error: 'unauthorized' });
    next();
  };
}

/** يتأكد أن هناك جلسة إدارة صالحة، وأن الحساب ما زال موجودًا */
function requireAuth(req, res, next) {
  const adminId = req.session && req.session.adminId;
  if (!adminId) return res.status(401).json({ error: 'not_authenticated' });

  const admin = db.getAdminById(adminId);
  if (!admin) {
    req.session = null;
    return res.status(401).json({ error: 'not_authenticated' });
  }

  req.admin = admin;
  next();
}

const USER_ID_REGEX = /^[1-9]\d{0,15}$/;

/** يحول اسم Roblox من الطلب إلى { id, name } أو يرمي خطأ بحالة HTTP مناسبة */
async function resolveUsername(username) {
  try {
    const user = await roblox.getUserByUsername(username);
    if (!user) {
      const err = new Error('roblox user not found');
      err.status = 404;
      throw err;
    }
    return user;
  } catch (e) {
    if (e instanceof roblox.RobloxError) {
      e.status = e.code === 'INVALID_USERNAME' ? 400 : e.code === 'RATE_LIMITED' ? 429 : 502;
    }
    throw e;
  }
}

function createApp() {
  const app = express();

  app.disable('x-powered-by');
  app.set('trust proxy', 1); // الاستضافات تضع proxy أمام التطبيق
  app.use(express.json({ limit: '2kb' }));
  app.use(
    cookieSession({
      name: 'session',
      secret: config.sessionSecret,
      maxAge: 12 * 60 * 60 * 1000, // 12 ساعة
      httpOnly: true,
      sameSite: 'lax',
    })
  );

  app.get('/health', (req, res) => res.json({ ok: true }));

  // ---------------- تسجيل دخول الإدارة ----------------
  const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 10,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    message: { error: 'too_many_attempts' },
  });

  app.post('/api/login', loginLimiter, async (req, res, next) => {
    try {
      const { username, password } = req.body || {};
      if (typeof username !== 'string' || typeof password !== 'string') {
        return res.status(400).json({ error: 'missing_fields' });
      }

      const admin = db.getAdminByUsername(username);
      // نتحقق حتى لو الحساب غير موجود، بهاش وهمي، لمنع معرفة أسماء الحسابات الصحيحة عبر توقيت الاستجابة
      const hashToCheck = admin ? admin.password_hash : '$2a$12$invalidsaltinvalidsaltinvalidsa';
      const ok = await auth.verifyPassword(password, hashToCheck);

      if (!admin || !ok) return res.status(401).json({ error: 'invalid_credentials' });

      req.session.adminId = admin.id;
      res.json({ ok: true, username: admin.username });
    } catch (err) {
      next(err);
    }
  });

  app.post('/api/logout', (req, res) => {
    req.session = null;
    res.json({ ok: true });
  });

  app.get('/api/me', requireAuth, (req, res) => {
    res.json({ username: req.admin.username });
  });

  // ---------------- لوحة الإدارة (تحتاج جلسة دخول) ----------------
  app.get('/api/activations', requireAuth, (req, res) => {
    const search = typeof req.query.search === 'string' ? req.query.search.slice(0, 50) : '';
    const limit = Math.min(Math.max(Number(req.query.limit) || 50, 1), 100);
    const offset = Math.max(Number(req.query.offset) || 0, 0);
    res.json({
      total: db.countActivations(),
      items: db.listActivations({ search, limit, offset }),
    });
  });

  app.post('/api/activations/activate', requireAuth, async (req, res, next) => {
    try {
      const { username } = req.body || {};
      if (typeof username !== 'string') return res.status(400).json({ error: 'username required' });

      const user = await resolveUsername(username);
      const { created, record } = db.activate({
        userId: user.id,
        username: user.name,
        activatedBy: req.admin.username,
      });
      res.status(created ? 201 : 200).json({ ok: true, created, record });
    } catch (err) {
      next(err);
    }
  });

  app.post('/api/activations/deactivate', requireAuth, async (req, res, next) => {
    try {
      const { username, userId } = req.body || {};

      let targetId;
      if (userId !== undefined) {
        const raw = String(userId);
        if (!USER_ID_REGEX.test(raw)) return res.status(400).json({ error: 'invalid_user_id' });
        targetId = Number(raw);
      } else if (typeof username === 'string') {
        const user = await resolveUsername(username);
        targetId = user.id;
      } else {
        return res.status(400).json({ error: 'username or userId required' });
      }

      const removed = db.deactivate(targetId);
      res.json({ ok: true, removed, userId: targetId });
    } catch (err) {
      next(err);
    }
  });

  // ---------------- Roblox: فحص التفعيل (محمي بمفتاح منفصل) ----------------
  const robloxLimiter = rateLimit({
    windowMs: 60 * 1000,
    limit: 600,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
  });

  app.get('/api/roblox/check/:userId', robloxLimiter, requireKey(config.robloxApiKey), (req, res) => {
    const raw = req.params.userId;
    if (!USER_ID_REGEX.test(raw)) return res.status(400).json({ error: 'invalid_user_id' });

    const userId = Number(raw);
    res.set('Cache-Control', 'no-store');
    res.json({ userId, activated: Boolean(db.getActivation(userId)) });
  });

  // ---------------- إعداد حسابات الإدارة (محمي بمفتاح منفصل) ----------------
  const setupLimiter = rateLimit({
    windowMs: 60 * 60 * 1000,
    limit: 20,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
  });

  app.post('/api/setup/admins', setupLimiter, requireKey(config.setupApiKey), async (req, res, next) => {
    try {
      const { username, password } = req.body || {};
      if (!auth.validUsername(username)) {
        return res.status(400).json({
          error: 'invalid_username',
          hint: 'حروف إنجليزية وأرقام و _ فقط، من 3 إلى 32 حرفًا',
        });
      }
      if (!auth.validPassword(password)) {
        return res.status(400).json({
          error: 'invalid_password',
          hint: `${auth.MIN_PASSWORD_LENGTH} أحرف على الأقل`,
        });
      }

      const passwordHash = await auth.hashPassword(password);
      const admin = db.upsertAdmin({ username, passwordHash });
      res.json({ ok: true, username: admin.username, totalAdmins: db.countAdmins() });
    } catch (err) {
      next(err);
    }
  });

  // ---------------- ملفات الموقع (صفحة الدخول ولوحة التحكم) ----------------
  app.use(express.static(path.join(__dirname, '..', 'public')));

  app.use((req, res) => res.status(404).json({ error: 'not_found' }));

  // معالج أخطاء موحّد: لا نكشف تفاصيل داخلية
  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'invalid_json' });
    const status = err.status && err.status >= 400 && err.status < 600 ? err.status : 500;
    if (status === 500) console.error('API error:', err);
    res.status(status).json({ error: status === 500 ? 'internal_error' : err.message });
  });

  return app;
}

module.exports = { createApp };
