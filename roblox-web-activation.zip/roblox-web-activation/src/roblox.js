'use strict';

// البحث عن حساب Roblox عن طريق الاسم للحصول على UserId (API رسمي عام من Roblox).

const USERNAME_REGEX = /^[A-Za-z0-9_]{3,20}$/;

class RobloxError extends Error {
  /** @param {'INVALID_USERNAME'|'RATE_LIMITED'|'NETWORK'|'API_ERROR'} code */
  constructor(code) {
    super(code);
    this.code = code;
  }
}

/**
 * @param {string} username
 * @returns {Promise<{id:number,name:string,displayName:string}|null>} null إذا الحساب غير موجود
 */
async function getUserByUsername(username) {
  if (typeof username !== 'string' || !USERNAME_REGEX.test(username)) {
    throw new RobloxError('INVALID_USERNAME');
  }

  let res;
  try {
    res = await fetch('https://users.roblox.com/v1/usernames/users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ usernames: [username], excludeBannedUsers: false }),
      signal: AbortSignal.timeout(8000),
    });
  } catch (err) {
    throw new RobloxError('NETWORK');
  }

  if (res.status === 429) throw new RobloxError('RATE_LIMITED');
  if (!res.ok) throw new RobloxError('API_ERROR');

  let json;
  try {
    json = await res.json();
  } catch {
    throw new RobloxError('API_ERROR');
  }

  const user = json && Array.isArray(json.data) ? json.data[0] : null;
  if (!user || !Number.isSafeInteger(user.id)) return null;

  return { id: user.id, name: user.name, displayName: user.displayName };
}

module.exports = { getUserByUsername, RobloxError, USERNAME_REGEX };
